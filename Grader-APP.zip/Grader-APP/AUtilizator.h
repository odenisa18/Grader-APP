#pragma once
#include<string>
class AUtilizator{
protected:
	std::string nume_utilizator;
	std::string parola;
public:
	AUtilizator(const std::string& nume_utilizator,const std::string& parola)
		:nume_utilizator(nume_utilizator), parola(parola) {};
	virtual void logIn()const=0;
	virtual void contActiv()const = 0;
	virtual ~AUtilizator()=default;
};