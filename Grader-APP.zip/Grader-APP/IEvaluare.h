#pragma once
#include<string>
#include<iostream>
#include"CStudent.h"
#include"CFileManager.h"
class IEvaluare//clasa __interface cu metode pur virtuale
{
public:
	virtual void printInfo()const = 0;
	virtual void printStudentAnswers(CStudent* s,const std::string&id)const=0;
	virtual void printResults(const CStudent* s, const std::string& id)const = 0;
	virtual void goTest(CStudent* s) = 0;
	virtual std::string getType()const=0;
	virtual float getNota(CStudent*s)const = 0;
	virtual std::string  getComentariu(CStudent*s)const = 0;
	virtual ~IEvaluare() = default;
};