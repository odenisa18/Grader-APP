#pragma once
#include"CAdministrator.h"
#include"CStudent.h"
#include"CProfesor.h"
#include"CGrupa.h"
#include"AEvaluare.h"
class MTAGrader{
private:
	static MTAGrader* instance;
	static CAdministrator* admin;
	static std::list<CStudent*>studenti;
	static std::list<CProfesor*>profesori;
	static std::list<CGrupa*>grupe;
	MTAGrader();
	~MTAGrader();
public:
	static MTAGrader* getInstance();
	void executa();
	void executaAdministrator();
	void loadGrupe(const std::string& grupeFILE);
	void loadStudents(const std::string& studentsFILE);
	void loadProfesori(const std::string& profesoriFILE);
	void adaugaStudentiLaGrupe();
	void adaugaProfesoriLaGrupe();
	void adaugaExameneLaGrupe(const std::string& exameneFILE);
	void adaugaExameneSustinute();
	void adaugaRezultate();
	void logInAsUser();
};

