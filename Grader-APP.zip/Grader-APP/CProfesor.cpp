#include "CProfesor.h"
#include"CStudent.h"
#include<iostream>
void CProfesor::logIn() const
{
	std::cout << "\nCadru didactic logat:" << nume_utilizator;
}

void CProfesor::contActiv() const
{
	std::cout << "\nContul cadrului didactic:" << nume_utilizator << " a fost creat si este activ.";
}

void CProfesor::adaugaEvaluare(const std::string& disciplina)
{
	evaluarePerDisciplina[disciplina]++;
}

void CProfesor::corecteazaExamen(AEvaluare* examenCurent, CStudent* s)
{
	float nota;
	std::string comentariu;
	const std::string id = examenCurent->getIDExamen();
	if (examenCurent->getType() == "Interviu")
	{
		std::cout << "\nSE AFISEAZA RASPUNSURILE LA INTERVIU:";
		examenCurent->printStudentAnswers(s,id);
	}
	else if (examenCurent->getType() == "Tema")
	{
		std::cout << "\nSE AFISEAZA RASPUNSURILE LA TEMA:";
		examenCurent->printStudentAnswers(s,id);
	}
	std::cout << "\nStudent:" << s->getStudentName();
	std::cout << "\nIntroduceti nota si comentariul pentru acest examen:";
	std::cin>>nota;
	std::cin.ignore();//ignor \n dupa nota\n
	std::getline(std::cin, comentariu);
	examenCurent->setNotaComentariu(s, nota, comentariu);
}
