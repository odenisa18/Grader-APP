#pragma once
#include<list>
#include<string>
#include"CStudent.h"
class AEvaluare;
class CFileManager{
public:
	static void loadFileProfesori(const std::string&filename,std::list<std::string>&dateProfi);
	static void loadFileStudenti(const std::string& filename, std::list<std::string>& dateStudenti);
	static void loadFileGrupe(const std::string& filename, std::list<std::string>& dateGrupe, const std::string& adminPass);
	static void loadFileExamene(const std::string& filename, std::list<std::string>& dateExamene, const std::string& adminPass);
	static void loadFileTema(const std::string& filename,std::string &cerinta,int &nrFisiereAcceptate);
	static void loadFileTestGrila(const std::string& filename, std::list<std::string>& intrebari, std::list<std::string>& varianteRaspuns, std::list<std::string>& raspunsuriCorecte);
	static void loadFileInterviu(const std::string& filename, std::list<std::string>& intrebari);
	static void loadExameneSustinute(const std::string& filename, std::list< std::string>& dateExameneSustinute);
	static void loadRaspunsuriInterviu(const std::string& filename, std::list< std::string>& dateraspunsuri);
	static void saveFisiereFinale(const std::string& filename, const std::string& numeStud);
	static void saveRaspunsuriInterviu(const std::string& filename, std::list< std::string> dateraspunsuri);
	static void saveFileExamene(const std::string& disciplina, const std::string& numeProf, const std::string& grupa, const std::string& tipExam, const std::string& examFILE);
	static void saveFileExameneSustinute(const std::string& filename, CStudent* s, AEvaluare* e, const std::string& fisiere);
	static void saveFilesToSingleFile(const std::string&zipFILE, const std::string&finalFILE);
	static void saveFileResults(const std::string& numeStud, const std::string& grupaStud, const std::string& idExamen, float nota, const std::string& comentariu);
	static std::string decrypt(const std::string& text, const std::string &key);
	static int getSumaParola(const std::string& parola);
};

