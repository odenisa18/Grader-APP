#include "CTema.h"
#include<iostream>
void CTema::printInfo() const
{
	std::cout << "\nNUMELE DISCIPLINEI EVALUATE:" << cod_disciplina;
	std::cout << "\nTIP EVALUARE:\t~TEMA~";
	std::cout << "\nCERINTA OBLIGATORIE:\n\t\t" << cerinta_tema;
	std::cout << "\nNUMARUL MAXIM DE FISIERE ACCEPTAT IN REZOLVAREA TEMEI:" << nrFisiereAcceptate;
	std::cout << "\nSucces!";
}

void CTema::goTest(CStudent* s)
{
	std::cout << "\nAcest tip de evaluare nu este una de tip test virtual.";
	std::cout << "\nPentru mai multe detalii verifica din nou cerintele.";
}
