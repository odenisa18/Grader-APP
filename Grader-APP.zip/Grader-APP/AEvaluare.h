#pragma once
#include "IEvaluare.h"
class AEvaluare :public IEvaluare{
protected:
	std::string id_evaluare;
	std::string cod_disciplina;
	bool dejaCorectat;
	std::string type;
	//lista de perechi de student cu pereche de nota+comentariu
	std::list<std::pair<CStudent*, std::pair<float, std::string>>> rezultate;
public:
	AEvaluare(const std::string& id, const std::string& cod)
		:id_evaluare{ id }, cod_disciplina{ cod } {};
    virtual void printInfo()const = 0;
	virtual void goTest(CStudent* s) = 0;
	virtual void printStudentAnswers(CStudent* s, const std::string& id)const = 0;
	float getNota(CStudent* s)const {
		for (auto& r : rezultate)
		{
			if (r.first == s)
			{
				return r.second.first;
			}
		}
	}
	std::string  getComentariu(CStudent* s)const {
		for (auto& r : rezultate)
		{
			if (r.first == s)
			{
				return r.second.second;
			}
		}
	}
	std::list<std::pair<CStudent*, std::pair<float, std::string>>> getResults()const 
	{
		return rezultate;
	}
	void printResults(const CStudent* s,const std::string&id)const override {
		for (auto& r : rezultate)
		{
			if (r.first==s) {
				std::cout << "\nNota:" << r.second.first;
				std::cout << "\nComentariu:" << r.second.second;
				break;
			}
		}
	}
	virtual std::string getType()const = 0;
	std::string getIDExamen()const 
	{
		return id_evaluare;
	}
	std::string Getcod_disciplina()const 
	{
		return cod_disciplina;
	}
	void setNotaComentariu(CStudent*s,float nota,const std::string comentariu)
	{
		rezultate.push_back({ s,{nota,comentariu} });
	}
	bool getCorectat()const 
	{
		return dejaCorectat;
	}
	virtual ~AEvaluare()=default;
};

