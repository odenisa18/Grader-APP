#pragma once
#include "AEvaluare.h"
#include<list>
#include<sstream>
#include<fstream>
class CTema :public AEvaluare{
private:
	std::string cerinta_tema;
	int nrFisiereAcceptate;
public:
	CTema(const std::string &id_evaluare, const std::string &cod_disciplina, const std::string& cerinta_tema, int nrFisiereAcceptate)
		:AEvaluare(id_evaluare, cod_disciplina), cerinta_tema{ cerinta_tema }, nrFisiereAcceptate{ nrFisiereAcceptate } {};
	void printInfo()const override;
	void goTest(CStudent* s)override;
	void addMaterial(CStudent* s, const std::string& filename)
	{
		CFileManager::saveFisiereFinale(filename, s->getStudentName());
	}
	void printStudentAnswers(CStudent* s, const std::string& id)const override
	{
		std::string numeFisier = s->getFisierExamen(id);
		if (numeFisier.empty())
		{
			std::cout << "\nNu a fost gasit fisierul cu raspunsuri pentru examenul cu ID-ul: " << id << ".\n";
			return;
		}
		std::ifstream f(numeFisier);
		if (!f)
		{
			std::cerr << "\nEroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
		}
		std::string fisiereTema;
		std::getline(f, fisiereTema);
		std::istringstream iss(fisiereTema);
		std::string fisier;
		while (iss >> fisier)
		{
			std::cout << "\n\nDeschid fisierul: " << fisier << "\n";
			std::ifstream fisierText(fisier);
			if (!fisierText)
			{
				std::cerr << "\nEroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
			}
			std::string linie;
			std::cout << "\n";
			while (std::getline(fisierText, linie))
			{
				std::cout << linie << "\n"; 
			}
			fisierText.close();
		}
		f.close();
	}
	void setType()
	{
		this->type = "Tema";
	}
	 std::string getType()const override
	{
		return type;
	}
	void setCorectat()
	{
		this->dejaCorectat = false;
	}
	~CTema()= default;
};

