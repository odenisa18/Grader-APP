#include "CAdministrator.h"
#include "CFileManager.h"

#include<iostream>
#include<thread>
#include<chrono>
void CAdministrator::createGrupa(const std::string& nume_grupa)
{
	CGrupa* c = new CGrupa(nume_grupa);
	grupe.push_back(c);
}

void CAdministrator::createStudent(const std::string& nume, const std::string& parola,const std::string &nume_grupa)
{
	CStudent* s = new CStudent(nume, parola, nume_grupa);	
	s->contActiv();
	studenti.push_back(s);
}

void CAdministrator::createProfesor(const std::string& nume, const std::string& parola)
{
	CProfesor* c = new CProfesor(nume, parola);
	c->contActiv();
	profesori.push_back(c);
}

void CAdministrator::addDisciplinaGrupaToProfesor(CProfesor* p, const std::string& disciplina, const std::string& grupa)
{
	p->setDisciplinaGrupa(grupa, disciplina);
}


void CAdministrator::logIn() const
{
	std::cout << "\nAdministrator logat in cont!";
}

void CAdministrator::contActiv() const
{
	std::cout << "\nContul Administratorului este acum activ!";
}

CAdministrator::~CAdministrator()
{
	for (auto& it : grupe)
	{
		delete it;
	}
	for (auto& it : studenti)
	{
		delete it;
	}
	for (auto& it : profesori)
	{
		delete it;
	}
}
