#Tema 1-OOP MTA GRADER a new step in exam automation

##Structura folderelor
In fereastra Solution Explorer,folderele sunt organizate dupa cum urmeaza:
-Singleton:
       *CFileManager se ocupa cu gestionarea(citirea/scrierea sau codificarea/decodificarea)
           tuturor fisierelor text ce vor fi utilizate in cadrul programului.
       *MTAGrader gestioneaza instantele de grupe,studenti si profesori si este responsabila pentru initializarea si 
         legatura dintre acestea.
-Utilizatori:
       *AUtilizator este o clasa abstracta din care derivez utilizatorii acestei aplicatii.(concept folosit:mostenire):
         **CAdministrator reprezinta un administrator care are rolul principal de a gestiona datele(profesori/studenti/grupe).
         **CStudent reprezinta un student care este asignat unei grupe de studii.
         **CProfesor reprezinta un profesor care este asignat unei/unor grupe de studii si poate preda una/mai multe materii.
       *CGrupa este o clasa concreta care are in compunere o lista de studenti si profesori cu acces permis,celor doua tipuri
        de utilizatori, la diverse modalitati de evaluare alese de profesor.Astfel: student->task:sa rezolve evaluarea
                                                                     profesor->task:sa verifice evaluarea(unde e necesar).
-Evaluare:
       *IEvaluare este o clasa de tip interfata cu metode pure virtuale din care derivez examenele aplicatiei.
        **AEvaluare este o clasa abstracta derivata din interfata care contine membrii comuni celor 3 clase derivate din ea.
         ***CTema reprezinta tema pe care un student o poate incarca prin intermediul unor fisiere text.
         ***CTestGrila reprezinta un examen de tip grila care poate fi corectat instant dupa incheierea examenului.
         ***CInterviu reprezinta un examen sub forma de dialog intre profesor si student prin intermediul unor intrebari oferite secvential.
-Fisiere ATM:
       *GrupeATM.txt fisier text cu lista numelor grupelor din universitate
       *ProfesoriATM.txt fisier text cu lista numelor profesorilor+parolele
       si materiile predate /grupa la care predau acea materie
       *StudentiATM.txt fisier text cu lista numelor de studenti din universitate,parolele si grupa din care fac parte
       *ExameneSustinuteATM.txt fisier text de tipul:
             Nume Student,Grupa Student,Disciplina Evaluata,Nume Profesor,Tip Examen+Nume Fisier Examen(pentru examene de tip TEMA SI INTERVIU)
       in care se salveaza printr-un proces tip backup de reincarcarea a informatiilor pentru fiecare utilizator ce examene au fost sustinute.
       *RezultateATM.txt fisier text de tipul:
             Nume Student,Grupa Student,ID Examen,Nota,Comentariu
        in care se salveaza printr-un proces tip backup de reincarcarea a informatiilor pentru fiecare utilizator ce nota si comentariu a primit fiecare.
###Utilizare

Pentru utilizare:
        1.Administratorul creeaza conturile pentru student si profesor.
        2.Se asigneaza fiecare utilizator la grupa de studii aferenta.
        3.Se adauga din fisierul de backup examenele deja adaugate de utilizatori(profesori) vezi:ExameneATM.txt
        4.Se adauga din fisierul de backup examenele deja lucrate de cate fiecare student in clasa sa pentru a sti ce examene au ramas de dat. vezi:ExameneSustinuteATM.txt
        5.Se adauga din fisierul de backup rezultatele pentru fiecare examen sustinut de catre studenti. vezi:RezultateATM.txt
        6.Partea de log in si cea mai importanta implica pentru profesor posibilitatea de a adauga un examen nou sau de a corecta unul deja existent:
        Pentru a adauga un examen sa tineti cont va rog de faptul ca se cere un fisier cu datele cerintei etc.
        Pentru corectare se cere idul examenului(il puteti lua din ExameneATM.txt,asta daca nu ati creat unul nou)

        Pentru student:
        El poate vedea ce examene disponibile are
        Ce examene a sustinut deja
        Poate sustine un examen(la sustinerea unui examen tema tineti cont ca daca sunt mai multe fisiere vor fi nrfisiere+1 adica fisierul cu toate temele scrise pe o linie si 
        cate un fisier pt fiecare ) vezi:eticaTemaStefanAndreea.txt
        Isi poate verifica notele pe baza id-ului de examen.

!Concepte insusite in cadrul acestei teme:incapsulare,mostenire,polimorfism.

I hope I did it good:)