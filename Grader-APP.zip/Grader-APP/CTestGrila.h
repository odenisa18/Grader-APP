#pragma once
#include "AEvaluare.h"
#include<list>
#include<iostream>
#include<string>
class CTestGrila :public AEvaluare{
private:
	std::list<std::string>intrebari;
	std::list<std::string>varianteRaspuns;
	std::list<std::string>raspunsuriCorecte;
public:
	CTestGrila(const std::string&id_evaluare,const std::string& cod_disciplina, std::list<std::string> intrebari, std::list<std::string> varianteRaspuns, std::list<std::string>raspunsuriCorecte)
		:AEvaluare(id_evaluare, cod_disciplina), intrebari{ intrebari }, varianteRaspuns{ varianteRaspuns },raspunsuriCorecte {
		raspunsuriCorecte
	} {
	};
	void printInfo()const override;
	void printStudentAnswers(CStudent* s, const std::string&id)const override
	{
		std::cout << "\nAcest examen nu are de afisat niciun raspuns."; return;
	}
    void goTest(CStudent* s) override;

	void setType()
	{
		this->type = "Test Grila";
	}
	std::string getType()const override
	{
		return type;
	}
	void setCorectat()
	{
		this->dejaCorectat = true;
	}

	~CTestGrila()=default;
};

