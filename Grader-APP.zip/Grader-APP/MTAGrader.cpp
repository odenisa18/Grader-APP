#include "MTAGrader.h"
#include"CFileManager.h"
#include"CAdministrator.h"
#include<iostream>
#include<sstream>

MTAGrader* MTAGrader::instance = nullptr;

CAdministrator* MTAGrader::admin = nullptr;

std::list<CStudent*>MTAGrader::studenti = {};
std::list<CProfesor*>MTAGrader::profesori = {};
std::list<CGrupa*>MTAGrader::grupe = {};

MTAGrader::MTAGrader()
{
	MTAGrader::admin = new CAdministrator("Denisa", "18");
	MTAGrader::grupe.clear();
	MTAGrader::studenti.clear();
	MTAGrader::profesori.clear();
}

MTAGrader::~MTAGrader()
{
	if (MTAGrader::instance)
	{
		delete MTAGrader::instance;
		MTAGrader::instance = nullptr;
	}
	delete MTAGrader::admin;
	for (auto& it :MTAGrader:: grupe)
	{
		delete it;
	}
	MTAGrader::grupe.clear();
	for (auto& it :MTAGrader:: studenti)
	{
		delete it;
	}
	MTAGrader::studenti.clear();
	for (auto& it :MTAGrader:: profesori)
	{
		delete it;
	}
	MTAGrader::profesori.clear();
}

MTAGrader* MTAGrader::getInstance()
{
	if (!MTAGrader::instance)
	{
		MTAGrader::instance = new MTAGrader;
	}
	return MTAGrader::instance;
}

void MTAGrader::executa()
{
	MTAGrader::executaAdministrator();
	MTAGrader::adaugaProfesoriLaGrupe();
	MTAGrader::adaugaStudentiLaGrupe();
	//mta adauga examene la grupe
	MTAGrader::adaugaExameneLaGrupe("ExameneATM.txt");
	MTAGrader::adaugaExameneSustinute();
	MTAGrader::adaugaRezultate();
	MTAGrader::logInAsUser();
}

void MTAGrader::executaAdministrator()
{
	MTAGrader::admin->contActiv();
	//se logheaza adminul
	MTAGrader::admin->logIn();
	//se citesc datele necesare-(GRUPE/STUDENTI/PROFESORI)
	MTAGrader::loadGrupe("GrupeATM.txt");
	MTAGrader::loadStudents("StudentiATM.txt");
	MTAGrader::loadProfesori("ProfesoriATM.txt");
	//se asigneaza datele de la ADMINISTRATOR la intreaga instanta a aplicatiei noastre
	MTAGrader::grupe = MTAGrader::admin->getGrupe();
	MTAGrader::studenti = MTAGrader::admin->getStudenti();
	MTAGrader::profesori = MTAGrader::admin->getProfesori();
}

void MTAGrader::loadGrupe(const std::string& grupeFILE)
{
	std::string adminPASS=MTAGrader::admin->getPassword();
	std::list<std::string>dateGrupe;
	CFileManager::loadFileGrupe(grupeFILE, dateGrupe, adminPASS);
	for (auto&linie : dateGrupe)
	{
		MTAGrader::admin->createGrupa(linie);
	}
}

void MTAGrader::loadStudents(const std::string& studentsFILE)
{
	std::cout << "\n";
	std::list<std::string>dateStudenti;
	CFileManager::loadFileStudenti(studentsFILE, dateStudenti);
	for (auto&linie : dateStudenti)
	{
		std::istringstream ss(linie);
		std::string n, p,g;
		std::getline(ss, n, ',');
		std::getline(ss, p, ',');
		std::getline(ss, g, ',');
		MTAGrader::admin->createStudent(n, p, g);
	}
}

void MTAGrader::loadProfesori(const std::string& profesoriFILE)
{
	std::cout << "\n";
	std::list<std::string>dateProfi;
	CFileManager::loadFileProfesori(profesoriFILE, dateProfi);
	for (auto&linie: dateProfi)
	{
		std::istringstream ss(linie);
		std::string n, p;
		std::getline(ss, n, ',');
		std::getline(ss, p, ',');
		
		MTAGrader::admin->createProfesor(n, p);
		CProfesor* prof = MTAGrader::admin->gettheLastProf();

		std::string d, g;
		while (std::getline(ss, d, ',') && std::getline(ss, g, ','))
		{
			MTAGrader::admin->addDisciplinaGrupaToProfesor(prof, d, g);
		}
	}
}

void MTAGrader::adaugaStudentiLaGrupe()
{
	std::cout << "\n";
	for (auto& s : MTAGrader::studenti)
	{
		for (auto& g : MTAGrader::grupe)
		{
			if (s->getGrupa() == g->getGrupa())
			{
				g->addStudent(s);
				std::cout << "\nStudentul " << s->getStudentName() << " a fost adaugat la grupa:" << s->getGrupa();
			}
		}
	}
}

void MTAGrader::adaugaProfesoriLaGrupe()
{
	std::cout << "\n";
	for (auto& p : MTAGrader::profesori)
	{
		for (auto& g : MTAGrader::grupe)
		{
			for (auto&p_dg : p->getDisciplina_grupa())
			{
				if (p_dg.second == g->getGrupa())
				{
					g->addProfesor(p, p_dg.first);
					std::cout << "\nProfesorul " <<p->getProfesorName() << " preda materia:"<<p_dg.first << " a fost adaugat la grupa:" << p_dg.second;
				}
			}
		}
	}
}

void MTAGrader::adaugaExameneLaGrupe(const std::string&exameneFILE)
{
	std::cout << "\n";
	//examenele sunt transmise instantei cfilemanager care incarca datele decriptate in lista de stringuri 

	std::string adminPASS = MTAGrader::admin->getPassword();//parola de decriptare

	std::list<std::string>dateExamene;//lista de stringuri decriptate

	CFileManager::loadFileExamene(exameneFILE, dateExamene, adminPASS);//proces citire-decriptare fisier examene

	//apoi citind linie cu linie identificam datele principale necesare in crearea unui examen
	for (auto&linie : dateExamene)
	{
		std::string numeProf, disciplinaProf, grupaProf, tipExam, examFILE;
		std::istringstream ss(linie);
		std::getline(ss,numeProf, ',');
		std::getline(ss, disciplinaProf, ',');
		std::getline(ss, grupaProf, ',');
		std::getline(ss, tipExam, ',');
		std::getline(ss, examFILE, ',');

		//caut grupa unde se creaza un nou examen
		for (auto& g : grupe)
		{
			//grupa compatibila cu cea a profesorului ?
			if (g->getGrupa() == grupaProf)
			{
				int nrCurent;
				//incrementez nr de evaluari pt disciplina predata de profesor
				for (auto& p : profesori)
				{
					if (p->getProfesorName() == numeProf)
					{
						p->adaugaEvaluare(disciplinaProf);
						//numar curent examen 
						nrCurent = p->getNumberofEvaluareforDisciplina(disciplinaProf);
					}
				}

				//adaug examenul in cadrul grupei !
				g->addExamen(numeProf,disciplinaProf,tipExam,examFILE,nrCurent);
			}
		}
	}
}

void MTAGrader::adaugaExameneSustinute()
{
	std::list< std::string> dateExameneSustinute;
	CFileManager::loadExameneSustinute("ExameneSustinuteATM.txt",dateExameneSustinute);
	for (auto& l : dateExameneSustinute)
	{
		std::string numeStud, grupaStud, idExam, numeProf, tipExam, examFILE, disciplina;
		std::istringstream ss(l);
		std::getline(ss, numeStud, ',');
		std::getline(ss, grupaStud, ',');
		std::getline(ss, disciplina, ',');
		std::getline(ss, idExam, ',');
		std::getline(ss, numeProf, ',');
		std::getline(ss, tipExam, ',');
		std::getline(ss, examFILE, ',');
		for (auto& s : studenti)
		{
			if (s->getStudentName() == numeStud) {
				s->examenSustinut(idExam, disciplina, numeProf);
				s->setFisierExamen(idExam, examFILE);
			}
		}
	}
}

void MTAGrader::adaugaRezultate()
{
	std::list< std::string> dateRezultate;
	CFileManager::loadExameneSustinute("RezultateATM.txt", dateRezultate);
	for (auto& l : dateRezultate)
		{
			std::string numeStud, grupaStud, idExam, comentariu;
			float nota;
			std::istringstream ss(l);
			std::getline(ss, numeStud, ',');
			std::getline(ss, grupaStud, ',');
			std::getline(ss, idExam, ',');
			ss >> nota;
			ss.ignore();
			std::getline(ss, comentariu, ',');
			CStudent* s=nullptr;
			for (auto& st : studenti)
			{
				if (st->getStudentName() == numeStud)
					s = st;
			}
			//caut grupa studentului
			for (auto& g : grupe)
			{
				if (g->getGrupa() == grupaStud)
				{
					//caut printre examene 
					for (auto& ex : g->getExamene())
					{
						if (ex->getIDExamen() == idExam)
						{
							ex->setNotaComentariu(s, nota, comentariu);
						}
					}
				}
			}
		}
}

void MTAGrader::logInAsUser()
{
	std::cout << "\n\n\t\tMTA GRADER SISTEM";
	std::string name, password;
	int nrMaximIncercari = 3;
	std::cout << "\nIntroduceti numele de utilizator pentru a va loga in cont:";
	std::getline(std::cin, name);
	int step;

	bool found = false;

	for (auto& s : studenti)
	{
			step = 0;
			while (step < nrMaximIncercari && s->getStudentName() == name)
			{
				std::cout << "\nParola:";
				std::cin >> password;
				step++;
				if (s->getStudentParola() == password)
				{
					while (true) {
						found = true;
						s->logIn();
						std::cout << "\n\t\t\tMeniu Sugestiv";
						std::cout << "\n\t1.Acces Examene Disponibile ";
						std::cout << "\n\t2.Istoric Examene Sustinute ";
						std::cout << "\n\t3.Sustine examen";
						std::cout << "\n\t4.Rezultate Examene";
						std::cout << "\n\tAlegeti optiunea dorita:__";
						char var;
						std::cin >> var;
						CGrupa* grupa = nullptr;
						for (auto& g : grupe)
						{
							if (s->getGrupa() == g->getGrupa())
							{
								grupa = g; break;
							}
						}
						switch (var)
						{
						case '1':
						{
							grupa->printExameneDisponibile(s); break;
						}
						case '2':
						{
							grupa->printIstoricExameneSustinute(s); break;
						}
						case '3':
						{
							grupa->sustineExamen(s); break;
						}
						case '4':
						{
							std::string id;
							std::cout << "\nIntroduceti id-ul examenului pe care doriti sa-l vizionati:";
							std::cin >>id;
							grupa->afisareRezultateExamen(s, id);
							break;
						}
						default:std::cout << "\nNu ati ales o varianta disponibila din meniu. "; break;
						}
						std::cout << "\nDoresti sa continui sa alegi o alta optiune?(DA/NU)";
						std::string continui;
						std::cin >> continui;
						if (continui == "NU" || continui!="DA")
						{
							std::cout << "\nAplicatia MTA Grader se va inchide.\n\t\tLa revedere!";
							return;
						}
					}
				}
				else {
					std::cout << "\nParola este invalida.Asigurati-va ca introduceti corect parola!";
					std::cout << "\nMai aveti " << nrMaximIncercari - step << " incercari valabile.";
					if (nrMaximIncercari - step == 0)exit(-1);
				}
			}
		}

	if (!found)
	{
		for (auto& p : profesori)
		{
			step = 0;
			while (step < nrMaximIncercari && p->getProfesorName() == name)
			{
					std::cout << "\nParola:";
					std::cin >> password;
					step++;
					if (p->getProfesorParola() == password)
					{
						found = true;
						p->logIn();
						std::cout << "\n\t\t\tMeniu Sugestiv";
						std::cout << "\n1.Adauga un Nou Examen";
						std::cout << "\n2.Evalueaza un Examen Incheiat";
						std::cout << "\nAlegeti optiunea dorita:__";
						char var;
						std::cin >> var;
						switch (var)
						{
						case '1':
						{
							std::string grupaNume,disciplina, type, examFILE;
							std::cout << "\nIntroduceti numele grupei evaluate:";
							std::cin >> grupaNume;
							std::cout << "\nIntroduceti numele disciplinei la care se face evaluarea:";
							std::cin.ignore();
							std::getline(std::cin, disciplina);
							std::cout << "\nIntroduceti tipul examenului:";
							std::getline(std::cin, type);
							std::cout << "\nIntroduceti fisierul cu informatiile despre examen:";
							std::cin>>examFILE;
							CGrupa* grupa = nullptr;
							bool found = false;
							for (auto& g : grupe)
							{
								if (g->getGrupa() == grupaNume)
								{
									grupa = g; found = true; break;
								}
							}
							if (!found)
							{
								std::cout << "\nGrupa introdusa nu exista!"; break;
							}
							else {
								grupa->adaugaExamenNou(p, disciplina, type,examFILE);
								break;
							}
						}
						case '2':
						{
							std::string grupaNume, disciplina;
							std::cout << "\nIntroduceti numele grupei evaluate:";
							std::cin >> grupaNume;
							std::cout << "\nIntroduceti numele disciplinei la care se face evaluarea:";
							std::cin >> disciplina;
							CGrupa* grupa = nullptr;
							bool found = false;
							for (auto& g : grupe)
							{
								if (g->getGrupa() == grupaNume)
								{
									grupa = g; found = true; break;
								}
							}
							if (!found)
							{
								std::cout << "\nGrupa introdusa nu exista!"; break;
							}
							else {
								grupa->corecteazaExamen(p, disciplina);
							}
							break;
						}
						default:std::cout << "\nNu ati ales o varianta disponibila din meniu. "; break;
						}
						break;
					}
					else { std::cout << "\nParola este invalida.Asigurati-va ca introduceti corect parola!"; 
					std::cout << "\nMai aveti " << nrMaximIncercari - step << " incercari valabile.";
					if (nrMaximIncercari - step == 0)
						exit(-1);
					}
			}
		}
	}
	if (!found)
	{
		std::cout << "\nNu exista niciun student/profesor cu un astfel de nume in sistem."; exit(-1);
	}
}