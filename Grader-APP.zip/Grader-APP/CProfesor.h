#pragma once
#include"AUtilizator.h"
#include"AEvaluare.h"
#include<list>
#include<unordered_map>
class CProfesor :public AUtilizator{
private:
	std::unordered_map<std::string, int>evaluarePerDisciplina;
	//fac o mapare a disciplinei cu un contor nr evaluari
	std::list < std::pair<std::string, std::string>>disciplina_grupa;
	//este o lista de perechi de tip disciplina+grupa
public:
	CProfesor(const std::string & nume_utilizator, const std::string & parola)
		:AUtilizator(nume_utilizator, parola) {};
	void logIn()const override;
	void contActiv()const override;
	void setDisciplinaGrupa(const std::string &grupa,const std::string &disciplina)
	{
		disciplina_grupa.push_back({disciplina,grupa});
	}
	void adaugaEvaluare(const std::string& disciplina);
	void corecteazaExamen(AEvaluare* examenCurent, CStudent* s);
	int getNumberofEvaluareforDisciplina(const std::string& disciplina)const 
	{
		auto it = evaluarePerDisciplina.find(disciplina);
		if (it != evaluarePerDisciplina.end())
		{
			return it->second;
		}
	}
	std::string getProfesorName()const
	{
		return nume_utilizator;
	}
	std::string getProfesorParola()const
	{
		return parola;
	}
	std::list < std::pair<std::string, std::string>>getDisciplina_grupa()const
	{
		return disciplina_grupa;
	}
	~CProfesor()=default;
};