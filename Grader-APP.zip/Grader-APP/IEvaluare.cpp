#include "IEvaluare.h"
