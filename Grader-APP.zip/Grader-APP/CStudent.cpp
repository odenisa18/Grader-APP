#include "CStudent.h"
#include<iostream>
void CStudent::logIn() const 
{
	std::cout << "\nStudent logat:" << nume_utilizator;
}

void CStudent::contActiv() const
{
	std::cout << "\nContul studentului:" << nume_utilizator << " a fost creat si este activ.";
}

void CStudent::examenSustinut(const std::string& idExamen,const std::string& disciplina, const std::string& numeProf)
{
	exameneSustinute.push_back({idExamen,numeProf });
}

void CStudent::printExameneSustinute() const
{
	if (exameneSustinute.empty())
	{
		std::cout << "\nNu ai sustinut niciun examen inca.";
	}
	else {
		for (auto& ex : exameneSustinute)
		{
			std::cout << "\nExamen la disciplina:" << ex.first << " sustinut.";
		}
	}
}
