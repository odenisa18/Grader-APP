#include "CTestGrila.h"
#include<sstream>
void CTestGrila::printInfo() const
{
	std::cout << "\nNUMELE DISCIPLINEI EVALUATE:" << cod_disciplina;
	std::cout << "\nTIP EVALUARE:\t~TEST GRILA~";
	std::cout << "\nSucces!";
}

void CTestGrila::goTest(CStudent* s) 
{
	std::cout << "\n3 2 1..Incepe testul!";

	float punctaj = 1;//+1 punct din oficiu

	//se pargurge testul intrebare cu intrebare
	auto intrebareCurenta = intrebari.begin();
	auto raspunsCurent = varianteRaspuns.begin();
	auto raspunsCorect = raspunsuriCorecte.begin();

	while (intrebareCurenta != intrebari.end() && raspunsCurent != varianteRaspuns.end())
	{
		std::cout << "\n" << *intrebareCurenta;
		std::cout << "\n" << *raspunsCurent;

		std::cout << "\nAlege raspunsul corect (a,b,c,d):";
		std::string rasp;
		std::cin >> rasp;
		if (rasp == "a" || rasp == "b" || rasp == "c" || rasp == "d") {
			if (rasp == *raspunsCorect)
			{
				//daca raspunsul curent e corect se aduna 0,5 puncte la punctaj
				punctaj += 1;
			}
		}
		else {
			std::cout<<"\nRaspunsul ales nu face parte din variantele de raspuns!";
			std::cout << "\nIntrodu o varianta valida!";
			continue;
		}
		++intrebareCurenta;
		++raspunsCurent;
	}
	std::cout << "\nFelicitari!Ati finalizat testul.Asteptati pentru afisarea rezultatelor.";
	if (punctaj < 5)
	{
		CFileManager::saveFileResults(s->getStudentName(), s->getGrupa(), CTestGrila::getIDExamen(), punctaj,"EXAMEN PICAT!" );
		setNotaComentariu(s,punctaj, "EXAMEN PICAT!");
	}
	else if (punctaj > 5 && punctaj < 7.5)
	{
		CFileManager::saveFileResults(s->getStudentName(), s->getGrupa(), CTestGrila::getIDExamen(), punctaj, "Acceptabil!");
		setNotaComentariu(s, punctaj, "Acceptabil!");
	}
	else if (punctaj > 7.5 && punctaj < 9)
	{
		CFileManager::saveFileResults(s->getStudentName(), s->getGrupa(), CTestGrila::getIDExamen(), punctaj, "Progresezi!");
		setNotaComentariu(s, punctaj, "Progresezi!");
	}
	else if (punctaj > 9 && punctaj!=10)
	{
		CFileManager::saveFileResults(s->getStudentName(), s->getGrupa(), CTestGrila::getIDExamen(), punctaj, "Foarte bine!");
		setNotaComentariu(s, punctaj, "Foarte bine!");
	}
	else if (punctaj == 10)
	{
		CFileManager::saveFileResults(s->getStudentName(), s->getGrupa(), CTestGrila::getIDExamen(), punctaj, "Felicitari!");
		setNotaComentariu(s, punctaj, "Felicitari!");
	}
}
