#include "CGrupa.h"
#include"CFileManager.h"
#include<iostream>
#include<sstream>
void CGrupa::addStudent(CStudent* s)
{
	studenti.push_back(s);
}

void CGrupa::addProfesor(CProfesor* c, const std::string& disciplina)
{
	profesori.push_back({c, disciplina});
}

void CGrupa::addExamen(const std::string&numeProf, const std::string& disciplina,const std::string &tipExam,const std::string& examFILE,int nrCurent)
{
	//creez id-ul unic pentru acest examen format din nrCurent+codDisciplina
		//(eu aleg ca codul sa fie direct disciplina in sine)
	std::string idUNIC = std::to_string(nrCurent) + disciplina;

	if (tipExam == "Tema")
	{
		std::string cerinta;
		int nrFisiereAcceptate;

		CFileManager::loadFileTema(examFILE, cerinta, nrFisiereAcceptate);

		CTema* t = new CTema(idUNIC,disciplina,cerinta,nrFisiereAcceptate);
		evaluari.push_back(t);
		t->setType();
		std::cout << "\nExamenul de tip Tema a fost adaugat grupei:" << this->nume_grupa << "  de catre prof. " << numeProf<<" .";
		std::cout << " Cu id unic:"<<idUNIC;
	}
	else if (tipExam == "Test Grila")
	{
		std::list<std::string>intrebari;
		std::list<std::string>varianteRaspuns;
		std::list<std::string>raspunsuriCorecte;

		CFileManager::loadFileTestGrila(examFILE,intrebari, varianteRaspuns, raspunsuriCorecte);

		CTestGrila* tg = new CTestGrila(idUNIC, disciplina, intrebari, varianteRaspuns, raspunsuriCorecte);
		evaluari.push_back(tg);
		tg->setType();
		std::cout << "\nExamenul de tip Test Grila a fost adaugat grupei:" << this->nume_grupa << " de catre prof. " << numeProf<<".";
		std::cout << " Cu id unic:" << idUNIC;
	}
	else if (tipExam == "Interviu")
	{
		std::list<std::string>intrebari;
		CFileManager::loadFileInterviu(examFILE, intrebari);

		CInterviu* i = new CInterviu(idUNIC, disciplina,intrebari);
		evaluari.push_back(i);
		i->setType();
		std::cout << "\nExamenul de tip Interviu a fost adaugat grupei:" << this->nume_grupa << " de catre prof. " << numeProf<<".";
		std::cout << " Cu id unic:" << idUNIC;
	}
}

void CGrupa::printExameneDisponibile(const CStudent* s)const
{
	std::list<std::pair<std::string, std::string>>exameneSustinute = s->getExameneSustinute();
	int disponibile = 0;
	for (auto& ev : evaluari)
	{
		bool found = false;
		for (auto& ex : exameneSustinute)
		{
			if (ev->getIDExamen() == ex.first)
			{
				found = true;
			}
		}
		if (!found)
		{
			disponibile++;
			std::cout << "\nUn examen la disciplina:" << ev->getIDExamen()<<" nu a fost sustinut.";
		}
	}
	if (disponibile == 0)
	{
		std::cout << "\nNu este niciun examen disponibil in acest moment."; return;					
	}
}

void CGrupa::printIstoricExameneSustinute(const CStudent* s)const
{
	std::list<std::pair<std::string, std::string>>exameneSustinute = s->getExameneSustinute();
	bool found = false;
	for (auto& ex : evaluari)
	{	for (auto& valid : exameneSustinute)
		{
			if (valid.first == ex->getIDExamen())
			{
				found = true;
				std::cout << "\nExamen cu id-ul:" << ex->getIDExamen() << " sustinut."; 
			}
		}
	}
	if (!found)
	{
		std::cout << "\nStudentul nu are un istoric cu examenele sustinute."; 
	}
	
}

void CGrupa::sustineExamen(CStudent* s)
{
	std::cout << "\nDoresti sa sustii un examen?";
	CGrupa::printExameneDisponibile(s);
	std::cout << "\nAlege examenul pe care vrei sa il sustii:";
	std::string idExamen, disciplina, prof;
	int nrId;
	std::cin.ignore();
	std::getline(std::cin,idExamen);
	std::istringstream iss(idExamen);
	iss >> nrId;
	iss >> disciplina;
	for (auto& p : profesori)
	{
		if (disciplina == p.second)
		{
			prof = p.first->getProfesorName(); break;
		}
	}
	s->examenSustinut(idExamen, disciplina, prof);
	bool found = false;
	for (auto& ex : evaluari)
	{
		if (ex->Getcod_disciplina() == disciplina && ex->getIDExamen() == idExamen)
		{
			std::string filename = "ExameneSustinuteATM.txt";
			found = true;
			ex->printInfo();
			std::cout << "\n";
			ex->goTest(s);
			if (ex->getType() == "Tema") {
				std::cout << "\nAi nevoie sa incarci un fisier?(DA/NU)";
				std::string raspuns;
				std::cin >> raspuns;
				std::string finalFILE = "";
				if (raspuns == "DA")
				{
					int nr;
					std::cout << "\nCate fisiere doresti sa incarci?";
					std::cin >> nr;
					std::cout << "\nIntrodu numele fisierului zip:";
					std::string zipFILE;
					std::cin >> zipFILE;
					for (int i = 0; i < nr; i++)
					{
						std::string filename;
						std::cout << "\nIntrodu numele fisierelor:";
						std::cin >> filename;
						finalFILE += filename + " ";
					}
					CFileManager::saveFilesToSingleFile(zipFILE, finalFILE);
					CFileManager::saveFileExameneSustinute(filename, s, ex, zipFILE);
					std::cout << "\nFisierul cu toate fisierele a fost salvat ca " << zipFILE << "\n";
				}
			}
			else if(ex->getType()=="Test Grila")
			{
				ex->printResults(s,idExamen);
				CFileManager::saveFileExameneSustinute(filename, s, ex,"noFILE");
			}
			else if (ex->getType() == "Interviu")
			{
				CFileManager::saveFileExameneSustinute(filename, s, ex,s->getFisierExamen(idExamen));
			}
		}
	}
	if (!found)
	{
		std::cout << "\nExamenul nu exista in lista examenelor disponibile";
	}
}

void CGrupa::afisareRezultateExamen(CStudent* s,const std::string& id)
{
	bool found = false;
	//caut studentul
	for (auto& st : studenti)
	{
		if (st == s)
		{
			//caut examenul
			for (auto& ex : evaluari)
			{
				//cand il gasesc
				if (ex->getIDExamen() == id)
				{
					//caut sa vad daca e in lista de rezultate studentul pt ACEL EXAMEN
					std::list<std::pair<CStudent*, std::pair<float, std::string>>> rezultate = ex->getResults();
					for (auto& r : rezultate)
					{
						if (r.first == s)
						{
							ex->printResults(s, id); found = true; break;
						}
					}
				}
			}
		}
	}
	if (!found)
	{
		std::cout << "\nAcest examen nu a fost inca corectat sau nu a fost sustinut.\nReveniti mai tarziu!"; return;
	}
}

void CGrupa::adaugaExamenNou(const CProfesor* c, const std::string& disciplina, const std::string& type, const std::string&examFILE)
{
	int nr = c->getNumberofEvaluareforDisciplina(disciplina);
	CFileManager::saveFileExamene(disciplina, c->getProfesorName(), CGrupa::getGrupa(),type, examFILE);
	CGrupa::addExamen(c->getProfesorName(), disciplina, type, examFILE, nr);
}

void CGrupa::corecteazaExamen(CProfesor* p, const std::string& disciplina)
{
	bool evaluate = false;
	for (auto& ex : evaluari)
	{
		if (ex->Getcod_disciplina() == disciplina && ex->getCorectat()==false)
		{
			std::cout << "\nExamenul cu id-ul: " << ex->getIDExamen();
		}
	}	
	std::cout << "\nAlegeti examenul pe care doriti sa il corectati:";
	std::string validare;
	std::cin.ignore();
	std::getline(std::cin,validare);
	//caut examenul ales
	for (auto& ex : evaluari)
	{
		if (ex->getIDExamen()==validare)
		{
			if (ex->getType() == "Test Grila")
			{
				std::cout << "\nAcest tip de examen a fost evaluat automat."; break;
			}
			//incep corectarea pentru studentii care deja au rezolvat examenul
			else {
				std::cout << "\nIncepe corectarea:";
				for (auto& s : studenti)
				{
					for (auto& exam : s->getExameneSustinute())
					{
						if (exam.first == ex->getIDExamen())
						{
							p->corecteazaExamen(ex, s); evaluate = true;
							std::string nume = s->getStudentName();
							std::string grupa = s->getGrupa();
							std::string id = ex->getIDExamen();
							float nota = ex->getNota(s);
							std::string com = ex->getComentariu(s);
							CFileManager::saveFileResults(nume, grupa, id, nota, com);
						}
					}
				}
			}
		}
	}
	if (!evaluate)
	{
		std::cout << "\nNu aveti inca examene de evaluat."; return;
	}
}
