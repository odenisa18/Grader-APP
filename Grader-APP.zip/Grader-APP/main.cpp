#include<iostream>
#include"MTAGrader.h"
int main()
{
	MTAGrader* instance = MTAGrader::getInstance();
	instance->executa();
	return 0;
}