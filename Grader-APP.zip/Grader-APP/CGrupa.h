#pragma once
#include"CStudent.h"
#include"CProfesor.h"
#include"AEvaluare.h"
#include"CTema.h"
#include"CTestGrila.h"
#include"CInterviu.h"
#include<list>
class CGrupa
{
private:
	std::string nume_grupa;
	std::list<CStudent*>studenti;
	//lista de perechi de tip
	//prof+disciplina
	std::list<std::pair<CProfesor*,std::string>>profesori;
	std::list<AEvaluare*>evaluari;//lista de examene
public:
	CGrupa(const std::string &nume_grupa)
		:nume_grupa{ nume_grupa } {};

	void addStudent(CStudent* s);

	void addProfesor(CProfesor* c,const std::string& disciplina);

	void addExamen(const std::string& numeProf, const std::string&disciplina, const std::string& tipExam, const std::string& examFILE,int nrCurent);

	void printExameneDisponibile(const CStudent*s)const ;

	void printIstoricExameneSustinute(const CStudent*s)const;

	void sustineExamen(CStudent* s);

	void afisareRezultateExamen(CStudent* s, const std::string& id);

	void adaugaExamenNou(const CProfesor*c,const std::string& disciplina,const std::string& type, const std::string& examFILE);

	void corecteazaExamen(CProfesor*p,const std::string & disciplina);

	std::list<AEvaluare* > getExamene()const
	{
		return evaluari;
	}
	 std::string getGrupa()const 
	{
		return nume_grupa;
	}
	~CGrupa()=default;
};