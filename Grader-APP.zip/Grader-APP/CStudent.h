#pragma once
#include "AUtilizator.h"
#include<list>
class CStudent :public AUtilizator{
private: std::string nume_grupa;
	   std::list<std::pair<std::string, std::string>>exameneSustinute;
	   //lista de perechi de tip idExamen+profesor care retine ce examene a sustinut studentul
	   std::list<std::pair<std::string, std::string>>fisiereExamene;
	   //lista de perechi de tip idExamen+fisier care retine ce rezolvarile tip fisier pentru examenele cu un anumit id
public:
	CStudent(const std::string &nume_utilizator,const std::string &parola,const std::string &nume_grupa)
		:AUtilizator(nume_utilizator, parola), nume_grupa{ nume_grupa } {};
	void logIn()const override;
	void contActiv()const override;
	void examenSustinut(const std::string& idExamen,const std::string& disciplina, const std::string& numeProf);
	void setFisierExamen(const std::string& idExamen,const std::string& numeFisier)
	{
		fisiereExamene.push_back({ idExamen,numeFisier });
	}
	void printExameneSustinute()const;
	std::string getFisierExamen(const std::string& id)
	{
		for (auto& i : fisiereExamene)
		{
			if (i.first == id)
			{
				return i.second;
			}
		}
	}
	std::string getStudentName()const 
	{
		return nume_utilizator;
	}
	std::string getStudentParola()const
	{
		return parola;
	}
	std::string getGrupa()const 
	{
		return nume_grupa;
	}
	std::list<std::pair<std::string, std::string>> getExameneSustinute()const
	{
		return exameneSustinute;
	}
	~CStudent() = default;
};