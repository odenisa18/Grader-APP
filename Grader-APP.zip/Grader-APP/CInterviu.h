﻿#pragma once
#include "AEvaluare.h"
class CInterviu :public AEvaluare{
private:
	std::list<std::string>intrebari;
public:
	CInterviu(const std::string& id_evaluare, const std::string& cod_disciplina, std::list<std::string>intrebari)
		:AEvaluare(id_evaluare, cod_disciplina) ,intrebari {intrebari} {};
	void printInfo()const override;

	void goTest(CStudent* s)
	{
		std::cout << "\nIntroduceti numele fisierului pentru raspunsuri:";
		std::string fileName;
		std::cin >> fileName;
		s->setFisierExamen(CInterviu::getIDExamen(),fileName);
		std::list<std::string> dateraspunsuri;
		std::cin.ignore();
		for (auto& i : intrebari)
		{
			std::string raspuns;
			std::cout << "\n" << i;
			std::getline(std::cin, raspuns);
			dateraspunsuri.push_back(raspuns);
		}
		CFileManager::saveRaspunsuriInterviu(fileName, dateraspunsuri);
	}
	void printStudentAnswers(CStudent* s, const std::string& id)const override
	{
		const std::string FisierRaspunsuriInterviu=s->getFisierExamen(id);
		if (FisierRaspunsuriInterviu.empty())
		{
			std::cout << "Nu a fost găsit fișierul cu răspunsuri pentru examenul cu ID-ul: " << id << ".\n";
			return;
		}
		std::list<std::string>raspunsuriInterviu;
		CFileManager::loadRaspunsuriInterviu(FisierRaspunsuriInterviu, raspunsuriInterviu);
		int nrQuestion = 0;
		for (auto& l : raspunsuriInterviu)
		{ 
			if (nrQuestion != 0)
			{
				std::cout << "\n" << nrQuestion << ")." << l;
			}
			nrQuestion++;
		}
	}
	void setCorectat() 
	{
		this->dejaCorectat = false;
	}
    std::string getType()const override
	{
		return type;
	}
	void setType()
	{
		this->type = "Interviu";
	}
	~CInterviu() = default;
};

