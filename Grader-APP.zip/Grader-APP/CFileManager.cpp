#include "CFileManager.h"
#include"AEvaluare.h"
#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
void CFileManager::loadFileProfesori(const std::string &filename,std::list<std::string >&dateProfi)
{
	std::ifstream f(filename);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	std::string linie;
	while (std::getline(f, linie))
	{
		std::istringstream ss(linie);
		std::string numeProf, parolaProf;
		
		std::getline(ss, numeProf, ',');
		std::getline(ss, parolaProf, ',');

		std::string newLinie = numeProf + "," + parolaProf;

		std::string disciplina, grupa;
		while (std::getline(ss, disciplina, ',') && std::getline(ss, grupa, ','))
		{
			//std::string grupadecriptata = CFileManager::decrypt(grupa, parolaProf);
			//std::string disciplinadecriptata = CFileManager::decrypt(disciplina, parolaProf);
			newLinie += "," + disciplina + "," + grupa;
		}
		dateProfi.push_back(newLinie);
	}
	
	f.close();
}
void CFileManager::loadFileStudenti(const std::string& filename, std::list<std::string>& dateStudenti)
{
	std::ifstream f(filename);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	std::string linie;
	while (std::getline(f, linie))
	{
		std::istringstream ss(linie);
		std::string numeStud, parolaStud, grupaStud;

		std::getline(ss, numeStud, ',');
		std::getline(ss, parolaStud, ',');
		std::string newLinie = numeStud + "," + parolaStud;

		std::getline(ss, grupaStud, ',');
		//std::string grupadecriptata = CFileManager::decrypt(grupaStud, parolaStud);
		newLinie += "," + grupaStud;
		dateStudenti.push_back(newLinie);
	}
	f.close();
}
void CFileManager::loadFileGrupe(const std::string& filename, std::list<std::string>& dateGrupe, const std::string &adminPass)
{
	std::ifstream f(filename);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	std::string grupaUniversitate;
	while (std::getline(f, grupaUniversitate))
	{
		//std::string grupaDecriptata = decrypt(grupaUniversitate, adminPass);
		dateGrupe.push_back(grupaUniversitate);
	}
	f.close();
}
void CFileManager::loadFileExamene(const std::string& filename, std::list<std::string>& dateExamene, const std::string& adminPass)
{
	std::ifstream f(filename);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	std::string linie;
	while (std::getline(f, linie))
	{
		//std::string liniedecriptata = decrypt(linie, adminPass);
		dateExamene.push_back(linie);
	}
	f.close();
}
void CFileManager::loadFileTema(const std::string& filename, std::string& cerinta, int& nrFisiereAcceptate)
{
	std::ifstream f(filename);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	std::string linie;
	while (std::getline(f, linie))
	{
		if (linie.find("Numar fisiere acceptate:") != std::string::npos)
		{
			size_t pos = linie.find(":");
			if (pos != std::string::npos)
			{
				std::string numarFisiereStr = linie.substr(pos + 1);
				nrFisiereAcceptate = std::stoi(numarFisiereStr);
			}
		}
		else {
			cerinta += linie + "\n";
		}
	}
	f.close();
}
void CFileManager::loadFileTestGrila(const std::string& filename, std::list<std::string>&intrebari,std::list<std::string>&varianteRaspuns,std::list<std::string>&raspunsuriCorecte)
{
	std::ifstream f(filename);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	std::string linie;
	intrebari.clear();
	while (std::getline(f, linie))
	{
		intrebari.push_back(linie);
		std::string varianteraspuns;
		for (int i = 0; i < 4; ++i) 
			{
				if (std::getline(f, linie))
				{
					varianteraspuns += linie + " "; //generez o linie cu citirea variantelor de raspuns din fisier
				}
			}
		varianteRaspuns.push_back(varianteraspuns);
		if (std::getline(f, linie))
		{
			raspunsuriCorecte.push_back(linie.substr(linie.find("Raspuns Corect:") + 15));
		}
	}
	f.close();
}
void CFileManager::loadFileInterviu(const std::string& filename, std::list<std::string>& intrebari)
{
	std::ifstream f(filename);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	std::string linie;
	while (std::getline(f, linie))
	{
		intrebari.push_back(linie);
	}
	f.close();
}

void CFileManager::loadExameneSustinute(const std::string& filename,std::list< std::string> &dateExameneSustinute)
{
	std::ifstream f(filename);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	std::string linie;
	while (std::getline(f, linie))
	{
		dateExameneSustinute.push_back(linie);
	}
	f.close();
}

void CFileManager::loadRaspunsuriInterviu(const std::string& filename, std::list<std::string>& dateraspunsuri)
{
	std::ifstream f(filename);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	std::string linie;
	while (std::getline(f, linie))
	{
		dateraspunsuri.push_back(linie);
	}
	f.close();
}

void  CFileManager::saveFisiereFinale(const std::string&filename,const std::string&numeStud)
{
	std::ofstream f(filename, std::ios::app);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	f << "\n"<<numeStud << "," << filename;
	f.close();
}

void CFileManager::saveRaspunsuriInterviu(const std::string& filename, std::list<std::string> dateraspunsuri)
{
	std::ofstream f(filename, std::ios::app);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	for (auto& i : dateraspunsuri)
	{
		f << "\n" << i;
}
	f.close();
}

void CFileManager::saveFileExamene(const std::string& disciplina,const std::string& numeProf,const std::string&grupa,const std::string& tipExam,const std::string& examFILE)
{
	std::ofstream f("ExameneATM.txt", std::ios::app);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	f << "\n" << numeProf << "," << disciplina << "," << grupa << "," << tipExam << "," << examFILE;
	f.close();
}

void CFileManager::saveFileExameneSustinute(const std::string& filename, CStudent* s, AEvaluare* e, const std::string& fisiere)
{
	std::ofstream f(filename, std::ios::app);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	f <<"\n" << s->getStudentName() << "," << s->getGrupa() << ",";
	for (auto&i: s->getExameneSustinute())
	{
		if (i.first == e->getIDExamen())
		{
			f <<e->Getcod_disciplina() <<"," << i.first << "," << i.second << "," << e->getType()<<"," << fisiere; break;
		}
	}
	f.close();
}

void CFileManager::saveFilesToSingleFile(const std::string& zipFILE, const std::string& finalFILE)
{
	std::ofstream f(zipFILE, std::ios::app);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	f << finalFILE;
	f.close();
}

void CFileManager::saveFileResults(const std::string& numeStud, const std::string& grupaStud, const std::string& idExamen, float nota, const std::string& comentariu)
{
	std::ofstream f("RezultateATM.txt", std::ios::app);
	if (!f)
	{
		std::cerr << "Eroare!Incercare de deschidere a fisierului invalida!" << std::endl; return;
	}
	f << numeStud << "," << grupaStud << "," << idExamen << "," << nota << "," << comentariu<<"\n";
	f.close();
}

std::string CFileManager::decrypt(const std::string& text, const std::string& key)
{
	std::string result;
	int suma_parola = CFileManager::getSumaParola(key);
	int cheie_decriptare = (suma_parola ^ key[0]) % 255;
	for (char c : text)
	{
		result += static_cast<char>(c ^ cheie_decriptare);
	}
	return result;
}

int CFileManager::getSumaParola(const std::string& parola)
{
	int suma = 0;
	for (char caracter : parola)
	{
		suma += static_cast<int>(caracter);
	}
	return suma;
}
