#include "CInterviu.h"

void CInterviu::printInfo() const
{
	std::cout << "\nIncepe Interviul.";
	std::cout << "\nVeti fi interviat de catre profesor.";
}

