#include "AEvaluare.h"
