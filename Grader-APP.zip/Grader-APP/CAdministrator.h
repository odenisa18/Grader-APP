#pragma once
#include "AUtilizator.h"
#include"CStudent.h"
#include"CProfesor.h"
#include"CGrupa.h"
#include"AEvaluare.h"
#include<list>
class CAdministrator :public AUtilizator
{
private:
	std::list<CStudent*>studenti;
	std::list<CProfesor*>profesori;
	std::list<CGrupa*>grupe;
public:
	CAdministrator(const std::string& nume_utilizator, const std::string& parola)
		:AUtilizator(nume_utilizator, parola) {};
	void createGrupa(const std::string& nume_grupa);
	void createStudent(const std::string &nume,const std::string &parola,const std::string &nume_grupa);
	void createProfesor(const std::string& nume, const std::string& parola);
	void addDisciplinaGrupaToProfesor(CProfesor* p, const std::string& disciplina, const std::string& grupa);
	void backup();
	void automaticBackup();
	void logIn()const override;
	void contActiv()const override;
	CProfesor* gettheLastProf()
	{
		return profesori.back();
	}
	std::list<CGrupa*> getGrupe()
	{
		return grupe;
	}
	std::list<CStudent*> getStudenti()const 
	{
		return studenti;
	}
	std::list<CProfesor*>getProfesori()const 
	{
		return profesori;
	}
	std::string getPassword()
	{
		return parola;
	}
	~CAdministrator();
};

